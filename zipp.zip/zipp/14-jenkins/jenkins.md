helm repo add jenkins https://charts.jenkins.io
helm repo update

helm upgrade --install jenkins jenkins/jenkins \
  --namespace jenkins \
  --values jenkins-values.yaml

kubectl get pods -n jenkins -w
kubectl get all -n jenkins
kubectl get ingress -n jenkins

kubectl exec -it -n jenkins $(kubectl get pods -n jenkins -l "app.kubernetes.io/component=jenkins-controller" -o jsonpath="{.items[0].metadata.name}") -- cat /run/secrets/additional/chart-admin-password && echo

kubectl get secret -n jenkins jenkins -o jsonpath="{.data.jenkins-admin-password}" | base64 --decode && echo

## Troubleshoot
kubectl logs jenkins-0 -n jenkins -c init 2>&1 | tail -50
kubectl logs jenkins-0 -n jenkins -c init --previous 2>&1 | tail -50
kubectl get pvc -n jenkins
kubectl get events -n jenkins --sort-by='.lastTimestamp' | tail -20

kubectl get configmap jenkins -n jenkins -o yaml | head -100
