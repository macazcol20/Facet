pipeline {
    agent any
    
    environment {
        HARBOR_REGISTRY = 'harbor.s3gis.be'
        HARBOR_PROJECT = 'library'  // Change this to your Harbor project name
    }
    
    stages {
        stage('Test Harbor Connection') {
            steps {
                script {
                    echo "Testing connection to Harbor at ${HARBOR_REGISTRY}"
                    
                    withCredentials([usernamePassword(
                        credentialsId: 'harbor-credentials',
                        usernameVariable: 'HARBOR_USER',
                        passwordVariable: 'HARBOR_PASS'
                    )]) {
                        sh '''
                            echo "Checking Harbor API..."
                            curl -k -u $HARBOR_USER:$HARBOR_PASS \
                                https://${HARBOR_REGISTRY}/api/v2.0/projects
                        '''
                    }
                }
            }
        }
        
        stage('List Harbor Projects') {
            steps {
                script {
                    withCredentials([usernamePassword(
                        credentialsId: 'harbor-credentials',
                        usernameVariable: 'HARBOR_USER',
                        passwordVariable: 'HARBOR_PASS'
                    )]) {
                        sh '''
                            echo "Listing all Harbor projects..."
                            curl -k -u $HARBOR_USER:$HARBOR_PASS \
                                https://${HARBOR_REGISTRY}/api/v2.0/projects \
                                | python3 -m json.tool || echo "Projects listed above"
                        '''
                    }
                }
            }
        }
    }
    
    post {
        success {
            echo "✅ Successfully connected to Harbor!"
            echo "Harbor Registry: ${HARBOR_REGISTRY}"
            echo "You can now build and push Docker images."
        }
        failure {
            echo "❌ Failed to connect to Harbor. Check your credentials."
        }
    }
}