pipeline {
    agent {
        kubernetes {
            yaml '''
apiVersion: v1
kind: Pod
metadata:
  labels:
    jenkins: agent
spec:
  containers:
  - name: docker
    image: docker:24-dind
    command:
    - cat
    tty: true
    securityContext:
      privileged: true
    volumeMounts:
    - name: docker-sock
      mountPath: /var/run
  - name: dind-daemon
    image: docker:24-dind
    securityContext:
      privileged: true
    volumeMounts:
    - name: docker-sock
      mountPath: /var/run
  volumes:
  - name: docker-sock
    emptyDir: {}
'''
        }
    }
    
    environment {
        HARBOR_REGISTRY = 'harbor.s3gis.be'
        HARBOR_PROJECT = 'library'
        IMAGE_NAME = 'test-app'
        IMAGE_TAG = "${env.BUILD_NUMBER}"
    }
    
    stages {
        stage('Prepare Dockerfile') {
            steps {
                container('docker') {
                    sh '''
                        cat > Dockerfile << 'EOF'
FROM nginx:alpine

RUN echo '<h1>Hello from Jenkins + Harbor!</h1>' > /usr/share/nginx/html/index.html && \
    echo '<p>Build Number: ${BUILD_NUMBER}</p>' >> /usr/share/nginx/html/index.html && \
    echo '<p>Built on: '$(date)' </p>' >> /usr/share/nginx/html/index.html && \
    echo '<p>Registry: harbor.s3gis.be</p>' >> /usr/share/nginx/html/index.html

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
EOF
                        echo "Dockerfile created:"
                        cat Dockerfile
                    '''
                }
            }
        }
        
        stage('Wait for Docker') {
            steps {
                container('docker') {
                    sh '''
                        echo "Waiting for Docker daemon to start..."
                        for i in $(seq 1 30); do
                            if docker info >/dev/null 2>&1; then
                                echo "Docker daemon is ready!"
                                docker info
                                break
                            fi
                            echo "Waiting... ($i/30)"
                            sleep 2
                        done
                    '''
                }
            }
        }
        
        stage('Build Docker Image') {
            steps {
                container('docker') {
                    sh '''
                        echo "Building Docker image..."
                        docker build -t ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG} .
                        docker tag ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG} \
                                   ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:latest
                        
                        echo "Images built:"
                        docker images | grep ${IMAGE_NAME}
                    '''
                }
            }
        }
        
        stage('Login to Harbor') {
            steps {
                container('docker') {
                    withCredentials([usernamePassword(
                        credentialsId: 'harbor-credentials',
                        usernameVariable: 'HARBOR_USER',
                        passwordVariable: 'HARBOR_PASS'
                    )]) {
                        sh '''
                            echo "Logging into Harbor..."
                            echo $HARBOR_PASS | docker login ${HARBOR_REGISTRY} \
                                --username $HARBOR_USER \
                                --password-stdin
                        '''
                    }
                }
            }
        }
        
        stage('Push to Harbor') {
            steps {
                container('docker') {
                    sh '''
                        echo "Pushing images to Harbor..."
                        docker push ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}
                        docker push ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:latest
                        
                        echo "Push completed successfully!"
                    '''
                }
            }
        }
        
        stage('Verify in Harbor') {
            steps {
                script {
                    withCredentials([usernamePassword(
                        credentialsId: 'harbor-credentials',
                        usernameVariable: 'HARBOR_USER',
                        passwordVariable: 'HARBOR_PASS'
                    )]) {
                        sh '''
                            echo "Verifying image in Harbor..."
                            curl -k -u $HARBOR_USER:$HARBOR_PASS \
                                "https://${HARBOR_REGISTRY}/api/v2.0/projects/${HARBOR_PROJECT}/repositories/${IMAGE_NAME}/artifacts" \
                                | grep -o '"digest":"[^"]*"' || echo "Image pushed successfully"
                        '''
                    }
                    
                    echo "✅ Image successfully pushed to Harbor!"
                    echo "📦 Image: ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}"
                    echo "🔗 View in Harbor: https://${HARBOR_REGISTRY}/harbor/projects/${env.HARBOR_PROJECT.hashCode().abs()}/repositories/${IMAGE_NAME}"
                }
            }
        }
    }
    
    post {
        always {
            container('docker') {
                sh '''
                    echo "Cleaning up..."
                    docker logout ${HARBOR_REGISTRY} || true
                    docker rmi ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG} || true
                    docker rmi ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:latest || true
                '''
            }
        }
        success {
            echo "🎉 Pipeline completed successfully!"
            echo "Image available at: ${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}"
            echo "View in Harbor: https://harbor.s3gis.be/harbor/projects"
        }
        failure {
            echo "❌ Pipeline failed. Check the logs above for details."
        }
    }
}