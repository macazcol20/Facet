## Step 1: Configure Harbor

### 1.1 Login to Harbor
Visit: https://harbor.s3gis.be/harbor/projects

### 1.2 Create a Project (if not exists)
1. Click "New Project"
2. Project Name: `myproject` (or any name you prefer)
3. Access Level: Choose "Public" or "Private"
4. Click "OK"

### 1.3 Create a Robot Account (Recommended for CI/CD)
1. Go to your project → "Robot Accounts"
2. Click "New Robot Account"
3. Name: `jenkins-robot`
4. Expiration: Set appropriate expiration
5. Permissions: Select "Push Artifact" and "Pull Artifact"
6. Click "Add"
7. **IMPORTANT**: Copy the token immediately - you won't see it again!

---

## Step 2: Add Harbor Credentials to Jenkins

### 2.1 Via UI
1. Go to: **Jenkins Dashboard** → **Manage Jenkins** → **Credentials**
2. Click: **System** → **Global credentials (unrestricted)**
3. Click: **Add Credentials**
4. Fill in:
   - **Kind**: Username with password
   - **Scope**: Global
   - **Username**: Your Harbor username (or robot account name like `robot$jenkins-robot`)
   - **Password**: Your Harbor password (or robot token)
   - **ID**: `harbor-credentials`
   - **Description**: Harbor Registry Credentials
5. Click **Create**

### 2.2 Via Kubernetes Secret (Alternative)
```bash
# Create a Kubernetes secret
kubectl create secret generic harbor-credentials \
  --from-literal=username='admin' \
  --from-literal=password='YOUR_HARBOR_PASSWORD' \
  -n jenkins

# The Jenkinsfile can reference this
```

---

## Step 3: Create a Pipeline Job in Jenkins

### 3.1 Create New Pipeline Job
1. Click **"+ New Item"** on Jenkins dashboard
2. Enter name: `docker-build-harbor`
3. Select: **Pipeline**
4. Click **OK**

### 3.2 Configure Pipeline
Scroll down to **Pipeline** section and choose one of these options:

#### Option A: Pipeline Script (Quick Test)
- Definition: **Pipeline script**
- Paste the contents of `Jenkinsfile-harbor` into the script box
- Update these variables in the `environment` section:
  ```groovy
  HARBOR_REGISTRY = 'harbor.s3gis.be'
  HARBOR_PROJECT = 'myproject'  // Your Harbor project name
  IMAGE_NAME = 'my-app'
  ```

#### Option B: Pipeline from SCM (Recommended)
- Definition: **Pipeline script from SCM**
- SCM: **Git**
- Repository URL: Your Git repository
- Branch: `*/main` (or your branch)
- Script Path: `Jenkinsfile`

### 3.3 Save and Build
1. Click **Save**
2. Click **Build Now**

---

## Step 4: Sample Repository Structure

Create a Git repository with these files:

```
my-app/
├── Dockerfile
├── Jenkinsfile
├── src/
│   └── (your application code)
└── README.md
```

Use the `Jenkinsfile-harbor` and `Dockerfile` provided in this guide.

---

## Step 5: Verify in Harbor

After a successful build:

1. Go to Harbor: https://harbor.s3gis.be/harbor/projects
2. Click on your project (e.g., "myproject")
3. You should see your image: `my-app` with tags `latest` and `<build-number>`
4. Click on the image to see:
   - Vulnerabilities (if scanning is enabled)
   - Tags
   - Build history

---

## Common Issues and Solutions

### Issue 1: "unauthorized: authentication required"
**Solution**: Check your Harbor credentials in Jenkins are correct

```bash
# Test Harbor login manually
docker login harbor.s3gis.be
# Enter your username and password
```

### Issue 2: "denied: requested access to the resource is denied"
**Solution**: Ensure your Harbor user has push permissions to the project

1. Go to Harbor → Your Project → Members
2. Add your user with "Developer" or "Maintainer" role

### Issue 3: Jenkins agent can't access Docker
**Solution**: The Kubernetes pod template in the Jenkinsfile mounts Docker socket. Ensure:
- Docker is available on the Kubernetes nodes
- Security policies allow privileged containers

### Issue 4: SSL/TLS certificate errors
**Solution**: If using self-signed certificates:

```groovy
// In Jenkinsfile, modify docker login:
sh """
    docker login ${HARBOR_REGISTRY} \
        --username \$HARBOR_USERNAME \
        --password-stdin \
        --tls-verify=false
"""
```

Or add Harbor's certificate to the Jenkins agent:
```dockerfile
# In your agent Dockerfile
COPY harbor-ca.crt /usr/local/share/ca-certificates/
RUN update-ca-certificates
```

---

## Alternative: Simple Test Pipeline

Here's a minimal pipeline to test Harbor connection:

```groovy
pipeline {
    agent any
    
    stages {
        stage('Test Harbor Connection') {
            steps {
                script {
                    withCredentials([usernamePassword(
                        credentialsId: 'harbor-credentials',
                        usernameVariable: 'USER',
                        passwordVariable: 'PASS'
                    )]) {
                        sh '''
                            echo "Testing connection to Harbor..."
                            curl -u $USER:$PASS https://harbor.s3gis.be/api/v2.0/projects
                        '''
                    }
                }
            }
        }
    }
}
```

---

## Next Steps

### 1. Set Up Webhooks (Automatic Builds)
Configure GitHub/GitLab webhooks to trigger Jenkins builds automatically:
- GitHub: Repository → Settings → Webhooks
- Webhook URL: `https://jenkins.s3gis.be/github-webhook/`

### 2. Add Image Scanning
Harbor automatically scans images for vulnerabilities. Configure scan policies:
- Harbor → Your Project → Configuration → Automatically scan images on push

### 3. Deploy to Kubernetes
Extend the pipeline to deploy to your Kubernetes cluster:

```groovy
stage('Deploy to Kubernetes') {
    steps {
        container('kubectl') {
            sh """
                kubectl set image deployment/my-app \
                    my-app=${HARBOR_REGISTRY}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG} \
                    -n production
            """
        }
    }
}
```

### 4. Add Notifications
Add Slack/Email notifications to your pipeline:

```groovy
post {
    success {
        slackSend(
            color: 'good',
            message: "Build ${env.BUILD_NUMBER} succeeded!"
        )
    }
}
```

---

## Monitoring and Logs

### View Build Logs
1. Jenkins → Your Job → Build Number → Console Output

### View Harbor Logs
```bash
# On Harbor server
kubectl logs -n harbor -l component=core
```

### View Jenkins Logs
```bash
kubectl logs -n jenkins jenkins-0 -f
```

---

## Security Best Practices

1. **Use Robot Accounts**: Don't use admin credentials in CI/CD
2. **Set Expiration**: Robot accounts should have expiration dates
3. **Minimal Permissions**: Only grant necessary permissions
4. **Rotate Credentials**: Regularly rotate robot account tokens
5. **Use Private Projects**: For sensitive images, use private Harbor projects
6. **Enable Content Trust**: Use Harbor's content trust for image signing
7. **Scan All Images**: Enable automatic vulnerability scanning

---

## Resources

- Jenkins Documentation: https://www.jenkins.io/doc/
- Harbor Documentation: https://goharbor.io/docs/
- Docker Documentation: https://docs.docker.com/
- Kubernetes Plugin for Jenkins: https://plugins.jenkins.io/kubernetes/

---

## Support

If you encounter issues:
1. Check Jenkins console logs
2. Check Harbor audit logs
3. Verify network connectivity between Jenkins and Harbor
4. Ensure correct credentials and permissions
