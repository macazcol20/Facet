# HashiCorp Vault - Production Environment Documentation

**Document Version:** 1.0  
**Last Updated:** January 18, 2026  
**Environment:** Production  
**Vault URL:** https://vault.pixiescloud.com  

---

## Executive Summary

This document provides an overview of the HashiCorp Vault implementation deployed for secure secrets management and PKI certificate automation. The environment implements role-based access control (RBAC) with four distinct team permissions, automated certificate lifecycle management, and integration with corporate Active Directory for authentication.

---

## 1. Environment Overview

### 1.1 Purpose

HashiCorp Vault serves as the centralized platform for:
- **Secrets Management**: Secure storage and access control for sensitive credentials (passwords, API keys, database credentials)
- **PKI Certificate Management**: Automated issuance, renewal, and lifecycle management of SSL/TLS certificates
- **Access Control**: Role-based permissions ensuring teams only access resources necessary for their function

### 1.2 Deployment Details

| Component | Details |
|-----------|---------|
| **Vault Server** | vault-pixie (10.0.0.X) |
| **Vault Version** | Enterprise/Community Edition |
| **Access URL** | https://vault.pixiescloud.com |
| **Management** | Terraform (Infrastructure as Code) |
| **Authentication** | Userpass, LDAP (Active Directory), AppRole |

---

## 2. Security Architecture

### 2.1 Team-Based Access Control

Four teams have been configured with specific permission levels:

#### Administrators Team
- **Access Level**: Full administrative control
- **Permissions**: 
  - Manage all policies and user accounts
  - Full access to secrets and certificates
  - Configure Vault settings and authentication methods
- **Use Case**: Vault platform administration and security management
- **Users**: admin1, admin2

#### Middleware Team
- **Access Level**: Operational - PKI and Secrets
- **Permissions**:
  - Issue and manage PKI certificates
  - Full read/write access to secrets
  - No administrative capabilities
- **Use Case**: Certificate automation, application credential management
- **Users**: middleware1, middleware2, middleware3

#### Security Team
- **Access Level**: Read-only auditing
- **Permissions**:
  - View all secrets and certificates (read-only)
  - View policies and authentication methods
  - Access audit logs
  - No write or delete capabilities
- **Use Case**: Security auditing, compliance reviews, incident investigation
- **Users**: security1, security2, auditor1

#### HCL Team
- **Access Level**: Secrets management only
- **Permissions**:
  - Full read/write access to secrets
  - No PKI certificate access
  - No administrative capabilities
- **Use Case**: Application configuration management, credential retrieval
- **Users**: hcl1, hcl2, hcl_dev1, hcl_dev2

### 2.2 Permission Matrix

| Capability | Administrators | Middleware | Security | HCL |
|------------|---------------|------------|----------|-----|
| **Issue PKI Certificates** | ✓ | ✓ | ✗ | ✗ |
| **View PKI Certificates** | ✓ | ✓ | ✓ | ✗ |
| **Read Secrets** | ✓ | ✓ | ✓ | ✓ |
| **Write Secrets** | ✓ | ✓ | ✗ | ✓ |
| **Delete Secrets** | ✓ | ✓ | ✗ | ✓ |
| **Manage Policies** | ✓ | ✗ | ✗ | ✗ |
| **View Policies** | ✓ | ✗ | ✓ | ✗ |
| **Manage Users** | ✓ | ✗ | ✗ | ✗ |
| **View Audit Logs** | ✓ | ✗ | ✓ | ✗ |

---

## 3. Authentication Methods

### 3.1 Userpass (Username/Password)

- **Purpose**: Direct user authentication for team members
- **Users**: 12 configured users across 4 teams
- **Token TTL**: 768 hours (32 days)
- **Password Policy**: Strong passwords required, managed via Terraform

### 3.2 LDAP (Active Directory Integration)

- **Purpose**: Enterprise authentication using existing AD credentials
- **Directory**: ldaps://ldap.bcbsnc.com
- **Domain**: BCBSNC.COM
- **Group Mappings**:
  - `BAU_admin_team` → Administrators Policy
  - `BAU_middleware_team` → Middleware Policy
  - `BAU_security_team` → Security Policy
  - `BAU_hcl_team` → HCL Policy

**Benefit**: Users authenticate with their existing corporate credentials; permissions are automatically assigned based on AD group membership.

### 3.3 AppRole (Application Authentication)

- **Purpose**: Machine-to-machine authentication for automated systems
- **Configured Roles**:
  - `middleware-app`: For certificate automation systems
  - `hcl-app`: For application credential retrieval
- **Token TTL**: 1 hour (renewable up to 24 hours)

**Benefit**: Applications authenticate without storing credentials; tokens are short-lived and automatically rotated.

---

## 4. Secrets Management

### 4.1 Secret Engine

- **Type**: Key-Value (KV) Version 1
- **Path**: `middlewaresecret/`
- **Purpose**: Centralized storage for application credentials and sensitive data

### 4.2 Stored Secrets

Current secret categories:

| Category | Path | Description |
|----------|------|-------------|
| **IBM LDAP Directory** | `middlewaresecret/IBM-LDAP-Directory/*` | LDAP credentials for dev, qa, pstage, prod |
| **Server Credentials** | `middlewaresecret/servers/*` | Root and service account credentials for servers |
| **Data Management** | `middlewaresecret/nwfDataMgmt/*` | Workflow data management credentials |
| **AIX Systems** | `middlewaresecret/aix/*` | AIX server credentials |

### 4.3 Access Pattern

```
Application → AppRole Auth → Token → Access Secret → Use Credential
     ↓
Audit Log Entry Created
```

---

## 5. PKI Certificate Management

### 5.1 Certificate Infrastructure

| Component | Details |
|-----------|---------|
| **Root CA** | Test Root CA |
| **Intermediate CA** | Test Intermediate CA (pki_int/) |
| **Certificate Types** | SSL/TLS certificates for applications |
| **Current Certificates** | 80+ active certificates |

### 5.2 Certificate Lifecycle

1. **Issuance**: Middleware team or automated systems request certificates
2. **Deployment**: Certificates automatically deployed to target servers
3. **Renewal**: Automated monitoring triggers renewal before expiration
4. **Revocation**: Certificates can be revoked when compromised

### 5.3 Automation

Certificate automation is configured for:
- **Kafka clusters**: Automatic certificate renewal and deployment
- **Renewal threshold**: Certificates renewed 7 days before expiration
- **Monitoring**: Daily checks via cron job

---

## 6. Compliance and Auditing

### 6.1 Access Logging

All Vault operations are logged including:
- User authentication attempts
- Secret read/write operations
- Certificate issuance and revocation
- Policy changes
- Administrative actions

### 6.2 Audit Capability

The Security team has read-only access to:
- All secret paths (without ability to modify)
- Certificate inventory
- Policy configurations
- Authentication method settings

### 6.3 Compliance Benefits

| Requirement | Vault Feature |
|-------------|---------------|
| **Access Control** | Role-based policies with least privilege |
| **Audit Trail** | Comprehensive logging of all operations |
| **Secret Rotation** | Supports automated credential rotation |
| **Encryption** | All data encrypted at rest and in transit |
| **Segregation of Duties** | Separate admin, operational, and audit roles |

---

## 7. Infrastructure as Code

### 7.1 Terraform Management

All Vault configuration is managed through Terraform:
- **Policies**: Defined in `.hcl` files, version controlled
- **Users**: Managed via Terraform variables
- **Secret Engines**: Configured and versioned
- **Authentication**: LDAP and AppRole settings in code

**Benefit**: All changes are tracked, reviewable, and can be rolled back if needed.

### 7.2 Configuration Repository

- **Location**: `~/vault-2026/terraform-new-for-the-team/`
- **Files**:
  - `main.tf` - Core configuration
  - `policies/*.hcl` - Team policy definitions
  - `secrets.tf` - Secret definitions
  - `terraform.tfvars` - Variables (passwords stored securely)

---

## 8. Operational Procedures

### 8.1 User Access Management

**Adding a New User:**
1. Update `terraform.tfvars` with new username and password
2. Run `terraform apply`
3. User can immediately login with assigned permissions

**Removing User Access:**
1. Remove user from `terraform.tfvars`
2. Run `terraform apply`
3. User's access is immediately revoked

### 8.2 Password Rotation

**Current Policy**: Passwords should be rotated every 90 days

**Process**:
1. Update password in `terraform.tfvars`
2. Apply changes via Terraform
3. Notify user of new credentials

### 8.3 Emergency Access

- Root token stored securely for emergency access
- Break-glass procedure documented for critical incidents
- All emergency access is logged and reviewed

---

## 9. Integration Points

### 9.1 Current Integrations

| System | Integration Type | Purpose |
|--------|-----------------|---------|
| **Active Directory** | LDAP Authentication | User authentication and authorization |
| **Kafka Clusters** | PKI Certificates | Automated certificate deployment |
| **Applications** | AppRole Authentication | Secure credential retrieval |

### 9.2 Future Integration Opportunities

- Database dynamic credentials
- Cloud provider secrets (AWS, Azure)
- Kubernetes service account management
- SSH certificate authority

---

## 10. Disaster Recovery

### 10.1 Backup Strategy

- **Terraform State**: Version controlled and backed up
- **Vault Data**: Regular snapshots recommended
- **Root Token**: Securely stored in multiple locations

### 10.2 Recovery Procedures

In case of Vault failure:
1. Restore Vault from backup
2. Unseal Vault using recovery keys
3. Verify authentication methods are operational
4. Reapply Terraform configuration if needed
5. Validate all integrations

---

## 11. Security Recommendations

### 11.1 Current Security Posture

✓ Role-based access control implemented  
✓ Least privilege principle enforced  
✓ Multi-factor authentication via LDAP integration  
✓ Short-lived tokens for applications  
✓ Comprehensive audit logging  

### 11.2 Recommended Enhancements

1. **Enable File Audit Backend**: Persistent logging to dedicated audit log file
2. **Implement Secret Rotation**: Automate credential rotation for stored secrets
3. **Regular Access Reviews**: Quarterly review of user access and permissions
4. **Backup Automation**: Implement automated Vault snapshot backups
5. **High Availability**: Consider Vault clustering for production resilience

---

## 12. Support and Contacts

### 12.1 Vault Administration

- **Primary Administrator**: [Contact Information]
- **Backup Administrator**: [Contact Information]
- **Emergency Contact**: [24/7 Contact]

### 12.2 Team Leads

| Team | Contact | Email |
|------|---------|-------|
| Administrators | [Name] | [Email] |
| Middleware | [Name] | [Email] |
| Security | [Name] | [Email] |
| HCL | [Name] | [Email] |

### 12.3 Escalation Path

1. Team Lead
2. Vault Administrator
3. Security Team
4. IT Management

---

## 13. Training and Documentation

### 13.1 Available Documentation

- **User Guide**: How to login and access secrets
- **Testing Guide**: Verification procedures for permissions
- **Operations Manual**: Day-to-day management procedures
- **Troubleshooting Guide**: Common issues and resolutions

### 13.2 Training Requirements

All users should complete:
- HashiCorp Vault basics
- Team-specific access procedures
- Security and compliance requirements
- Incident reporting procedures

---

## 14. Change Management

### 14.1 Change Control Process

All Vault changes follow this process:
1. **Request**: Change requested via ticket/email
2. **Review**: Vault administrator reviews impact
3. **Approval**: Management approval for significant changes
4. **Implementation**: Applied via Terraform
5. **Validation**: Tested before production deployment
6. **Documentation**: This document updated as needed

### 14.2 Change History

| Date | Change | Implemented By |
|------|--------|---------------|
| 2026-01-18 | Initial 4-team structure deployment | Vault Administrator |
| 2026-01-17 | Certificate automation configured | Middleware Team |
| 2026-01-17 | LDAP integration enabled | Vault Administrator |

---

## 15. Metrics and Reporting

### 15.1 Key Metrics

Track monthly:
- Number of active users per team
- Secret access frequency
- Certificate issuance volume
- Failed authentication attempts
- Policy violations

### 15.2 Reporting

**Monthly Report Includes**:
- User access summary
- Certificate inventory
- Security incidents
- Compliance status
- Recommendations for improvements

---

## Appendix A: Quick Reference

### User Login

```bash
# Userpass
vault login -method=userpass username=<your_username>

# LDAP
vault login -method=ldap username=<ad_username>
```

### Access Secrets

```bash
# Read secret
vault kv get middlewaresecret/path/to/secret

# Write secret (if permitted)
vault kv put middlewaresecret/path/to/secret key=value
```

### View Certificates

```bash
# List all certificates
vault list pki_int/certs

# View CA certificate
vault read pki_int/cert/ca
```

---

## Appendix B: Glossary

| Term | Definition |
|------|------------|
| **AppRole** | Authentication method for applications and services |
| **KV** | Key-Value secret engine for storing arbitrary secrets |
| **LDAP** | Lightweight Directory Access Protocol, used for AD integration |
| **PKI** | Public Key Infrastructure, certificate management system |
| **Policy** | Set of rules defining what a user/application can access |
| **Token** | Temporary credential issued after authentication |
| **TTL** | Time To Live, duration a token or secret is valid |

---

**Document Control**

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-01-18 | Vault Admin | Initial documentation |

---

*This document is maintained by the Vault Administration team and should be reviewed quarterly or when significant changes occur.*
