# Vault Team-Based Access Control with Identity Groups

## 📋 Overview

This configuration uses **Vault Identity Groups** for team-based access control - a cleaner, more scalable approach than namespaces.

### ✅ What's New:
- **Identity Groups** instead of namespaces
- **Group-based permissions** for easier management
- **LDAP Group Aliases** for automatic AD integration
- **No namespace complexity** - simpler paths
- **Entity tracking** for better auditing

###

 🏗️ Architecture:

```
┌─────────────────────────────────────────────────────────────┐
│ Authentication Layer                                         │
│  ├── Userpass (username/password)                           │
│  ├── LDAP (Active Directory)                                │
│  └── AppRole (applications)                                 │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ Identity Layer (NEW!)                                        │
│  ├── Entities (individual users)                            │
│  ├── Groups (team-based)                                    │
│  │    ├── administrators-group                              │
│  │    ├── middleware-group                                  │
│  │    ├── security-group                                    │
│  │    └── hcl-group                                         │
│  └── LDAP Group Aliases (AD → Vault)                        │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ Policy Layer                                                 │
│  ├── administrators-policy (full access)                    │
│  ├── middleware-policy (PKI + secrets)                      │
│  ├── security-policy (read-only)                            │
│  └── hcl-policy (secrets only)                              │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ Resources                                                    │
│  ├── middlewaresecret/* (KV v1 secrets)                     │
│  ├── pki/* (root PKI)                                       │
│  └── pki_int/* (intermediate PKI)                           │
└─────────────────────────────────────────────────────────────┘
```

## 📁 File Structure

```
vault-team-permissions-groups/
├── README.md                         # This file
├── QUICKSTART.md                     # Quick reference
├── provider.tf                       # Terraform provider config
├── variables.tf                      # Variable definitions
├── terraform.tfvars                  # YOUR VALUES (change passwords!)
├── policies.tf                       # Policy loader
├── main.tf                           # Main config with groups
├── secrets.tf                        # Your existing secrets
└── policies/                         # Policy files directory
    ├── administrators-policy.hcl     # Full access
    ├── middleware-policy.hcl         # PKI + Secrets
    ├── security-policy.hcl           # Read-only
    └── hcl-policy.hcl                # Secrets only
```

## 🚀 Quick Start

### Step 1: Clean Up Old Deployment

```bash
cd ~/vault-2026/terraform-new-for-the-team

# Destroy old namespace-based deployment
terraform destroy
```

### Step 2: Setup New Directory

```bash
cd ~/vault-2026
mkdir vault-team-groups
cd vault-team-groups

# Upload all files from the ZIP
```

### Step 3: Edit terraform.tfvars

**CHANGE ALL PASSWORDS!**

```hcl
vault_address = "https://vault.pixiescloud.com"
vault_token   = "hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

admin_passwords = {
  admin1 = "YourStrongAdminPassword1!"
  admin2 = "YourStrongAdminPassword2!"
}

# ... rest of passwords
ldap_bindpass = "YourActualLDAPBindPassword"
```

### Step 4: Initialize and Apply

```bash
cd ~/vault-2026/vault-team-groups

# Initialize
terraform init

# Import existing auth methods if they exist
terraform import vault_auth_backend.userpass userpass
terraform import vault_ldap_auth_backend.ldap_config ldap

# Apply
terraform plan
terraform apply
```

## 🎯 Key Advantages of Groups

### 1. **Simpler Paths**
```bash
# OLD (with namespace):
vault kv get middlewarenamespace/middlewaresecret/IBM-LDAP-Directory/dev

# NEW (with groups):
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
```

### 2. **Better User Management**
```bash
# View user's identity
vault read identity/entity/name/middleware1

# View group membership
vault read identity/group/name/middleware-group

# List all groups
vault list identity/group/name
```

### 3. **Automatic LDAP Integration**
```
AD Group: BAU_middleware_team
    ↓ (LDAP Group Alias)
Vault Group: middleware-group
    ↓ (Group Policies)
Policies: middleware-policy
    ↓
Access: PKI + Secrets
```

### 4. **Easy to Add/Remove Users**
```bash
# Add user to group (example)
vault write identity/group/name/middleware-group \
  member_entity_ids=entity_id_1,entity_id_2
```

## 🧪 Testing

### Test Middleware User

```bash
# Login
vault login -method=userpass username=middleware1

# ✅ Test PKI access
vault list pki_int/certs
vault read pki_int/cert/ca

# ✅ Test secrets access
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
vault kv put middlewaresecret/test/myapp password="test123"

# ❌ Test admin access (should fail)
vault policy list
```

### Test Security User (Read-Only)

```bash
# Login
vault login -method=userpass username=security1

# ✅ Test read access
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
vault list pki_int/certs
vault policy list

# ❌ Test write access (should fail)
vault kv put middlewaresecret/test/denied password="fail"
```

### Test HCL User

```bash
# Login
vault login -method=userpass username=hcl1

# ✅ Test secrets access
vault kv get middlewaresecret/servers/lxdbd2p101
vault kv put middlewaresecret/hcl/myapp apikey="test123"

# ❌ Test PKI access (should fail)
vault list pki_int/certs
```

### Test Group Membership

```bash
# Login as any user
vault login -method=userpass username=middleware1

# View your entity
vault read identity/entity/name/middleware1

# Output shows:
# - entity_id
# - groups (should include middleware-group)
# - policies
```

## 📊 Team Permissions

| Team | PKI Certs | Secrets | Vault Admin | Group |
|------|-----------|---------|-------------|-------|
| **Administrators** | Full | Full | Full | administrators-group |
| **Middleware** | Full | Full | None | middleware-group |
| **Security** | Read-only | Read-only | Read-only | security-group |
| **HCL** | None | Full | None | hcl-group |

## 🔐 LDAP Integration

### AD Group Mapping:

| AD Group | Vault Group | Policies | Access |
|----------|-------------|----------|--------|
| BAU_admin_team | administrators-group | administrators-policy | Full |
| BAU_middleware_team | middleware-group | middleware-policy | PKI + Secrets |
| BAU_security_team | security-group | security-policy | Read-only |
| BAU_hcl_team | hcl-group | hcl-policy | Secrets |

### LDAP Login:

```bash
# User logs in with LDAP
vault login -method=ldap username=john.doe

# Vault automatically:
# 1. Authenticates against AD
# 2. Checks AD group membership (e.g., BAU_middleware_team)
# 3. Maps to Vault group (middleware-group)
# 4. Applies policies (middleware-policy)
# 5. Grants access based on policy
```

## 📝 Managing Groups

### View All Groups:

```bash
vault list identity/group/name
```

### View Group Details:

```bash
vault read identity/group/name/middleware-group
```

### View Group Members:

```bash
vault read identity/group/name/middleware-group

# Shows:
# - member_entity_ids (list of users)
# - policies attached
# - metadata
```

### Add User to Group Manually:

```bash
# Get user's entity ID
ENTITY_ID=$(vault read -format=json identity/entity/name/newuser | jq -r '.data.id')

# Get group ID
GROUP_ID=$(vault read -format=json identity/group/name/middleware-group | jq -r '.data.id')

# Add user to group
vault write identity/group/name/middleware-group \
  member_entity_ids=$ENTITY_ID
```

## 🔧 Troubleshooting

### User can't access secrets:

```bash
# Check entity
vault read identity/entity/name/username

# Check group membership
vault list identity/group/name

# Check policies on group
vault read identity/group/name/middleware-group
```

### LDAP user not getting policies:

```bash
# Check LDAP group alias
vault list identity/group-alias/id

# Check if AD group matches Vault alias
vault read identity/group/name/middleware-group
# Look for "alias" section
```

### Policy not working:

```bash
# Re-apply policies
cd ~/vault-2026/vault-team-groups
terraform apply

# Test policy directly
vault policy read middleware-policy
```

## 🆕 Adding New Users

### Via Terraform (Recommended):

Edit `terraform.tfvars`:

```hcl
middleware_users = {
  middleware1 = "Pass1!"
  middleware2 = "Pass2!"
  middleware3 = "Pass3!"
  middleware4 = "Pass4!"  # New user
}
```

Then apply:
```bash
terraform apply
```

The new user is automatically:
1. Created in userpass
2. Assigned an entity
3. Added to middleware-group
4. Granted middleware-policy

### Manually (Temporary):

```bash
# Create user
vault write auth/userpass/users/tempuser password="TempPass123!"

# Create entity
vault write identity/entity name=tempuser policies="middleware-policy"

# Get entity ID
ENTITY_ID=$(vault read -format=json identity/entity/name/tempuser | jq -r '.data.id')

# Add to group
vault write identity/group/name/middleware-group \
  member_entity_ids="$ENTITY_ID"
```

## 📈 Next Steps

1. ✅ Apply this configuration
2. ✅ Test all 4 team access levels
3. ✅ Create AD groups (BAU_admin_team, BAU_middleware_team, etc.)
4. ✅ Test LDAP authentication
5. ✅ Update certificate automation to use AppRole
6. ✅ Enable audit logging:
   ```bash
   vault audit enable file file_path=/var/log/vault_audit.log
   ```
7. ✅ Monitor group membership regularly
8. ✅ Document for your teams

## ✅ Production Checklist

- [ ] All passwords changed from defaults
- [ ] terraform.tfvars not in Git
- [ ] All 4 teams tested with userpass
- [ ] AD groups created
- [ ] LDAP authentication tested
- [ ] AppRole configured for automation
- [ ] Audit logging enabled
- [ ] Group membership documented
- [ ] Access review schedule established

---

**Your Vault now has modern, scalable group-based access control!** 🎉
