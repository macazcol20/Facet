# Phase 3: Kafka Server Setup - Create "Existing" Certificates

## 🧹 STEP 1: Clean Up Kafka Server (Optional - if re-running)

```sh
# SSH to mainframe
ssh cafanwii@10.0.0.15

# Remove all existing certificates
rm -rf ~/certs/kafka/kafkasandbox/*

# Verify clean
ls -la ~/certs/kafka/kafkasandbox/

echo "✅ Kafka server cleaned - ready for fresh certificates"
```

---

## 🔐 STEP 2: Create Certificate Infrastructure on Kafka Server

This simulates your existing production certificates.

```sh
# On mainframe (10.0.0.15) as cafanwii
mkdir -p ~/certs/kafka/kafkasandbox
cd ~/certs/kafka/kafkasandbox

# ============================================
# 1. CREATE ROOT CA (simulating BCBSNCRoot)
# ============================================

# Generate Root CA private key
openssl genrsa -out BCBSNCRoot.key 4096

# Generate Root CA certificate
openssl req -x509 -new -nodes \
  -key BCBSNCRoot.key \
  -sha256 -days 3650 \
  -out BCBSNCRoot.cer \
  -subj "/C=US/ST=Florida/L=Orlando/O=Test Corp/OU=IT/CN=Test Root CA"

echo "✅ Root CA created"

# ============================================
# 2. CREATE INTERMEDIATE CA (simulating BCBSNCIntermediate)
# ============================================

# Generate Intermediate CA private key
openssl genrsa -out BCBSNCIntermediate.key 4096

# Generate Intermediate CSR
openssl req -new \
  -key BCBSNCIntermediate.key \
  -out BCBSNCIntermediate.csr \
  -subj "/C=US/ST=Florida/L=Orlando/O=Test Corp/OU=IT/CN=Test Intermediate CA"

# Sign Intermediate with Root CA
openssl x509 -req \
  -in BCBSNCIntermediate.csr \
  -CA BCBSNCRoot.cer \
  -CAkey BCBSNCRoot.key \
  -CAcreateserial \
  -out BCBSNCIntermediate.cer \
  -days 1825 -sha256 \
  -extfile <(echo "basicConstraints=CA:TRUE")

echo "✅ Intermediate CA created"

# ============================================
# 3. CREATE KAFKA SERVER CERTIFICATE (simulating sandbox.crt)
# ============================================

# Generate server private key
openssl genrsa -out sandbox.key 2048

# Create certificate request
openssl req -new \
  -key sandbox.key \
  -out sandbox.csr \
  -subj "/C=US/ST=Florida/L=Orlando/O=Test Corp/OU=Kafka/CN=mainframe"

# Create SAN config file
cat > san.conf <<EOF
[req]
distinguished_name = req_distinguished_name
req_extensions = v3_req
prompt = no

[req_distinguished_name]
C = US
ST = Florida
L = Orlando
O = Test Corp
OU = Kafka
CN = mainframe

[v3_req]
keyUsage = keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth, clientAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = mainframe
DNS.2 = mainframe.local
DNS.3 = localhost
IP.1 = 10.0.0.15
IP.2 = 10.0.0.2
IP.3 = 127.0.0.1
EOF

# Sign server certificate with Intermediate CA
openssl x509 -req \
  -in sandbox.csr \
  -CA BCBSNCIntermediate.cer \
  -CAkey BCBSNCIntermediate.key \
  -CAcreateserial \
  -out sandbox.crt \
  -days 365 -sha256 \
  -extensions v3_req \
  -extfile san.conf

echo "✅ Server certificate created"

# ============================================
# 4. CREATE CA BUNDLE
# ============================================

# Create CA chain (Intermediate + Root)
cat BCBSNCIntermediate.cer BCBSNCRoot.cer > cacerts.crt

echo "✅ CA bundle created"

# ============================================
# 5. CREATE ADDITIONAL FILES (matching production)
# ============================================

# Create passphrase file
echo "changeme123!" > passphrase.txt
chmod 600 passphrase.txt

# Set proper permissions
chmod 600 sandbox.key BCBSNCRoot.key BCBSNCIntermediate.key
chmod 644 sandbox.crt BCBSNCRoot.cer BCBSNCIntermediate.cer cacerts.crt

# ============================================
# 6. VERIFY SETUP
# ============================================
ls -lh ~/certs/kafka/kafkasandbox/

openssl x509 -in sandbox.crt -noout -subject -issuer -dates

openssl x509 -in sandbox.crt -noout -ext subjectAltName

openssl verify -CAfile cacerts.crt sandbox.crt

```

