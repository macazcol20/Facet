# Phase 4: Vault Server Setup (Part 2) - Import Existing CA & Automate

## 🎯 What We're Doing

**Production Scenario:**
You have existing certificates on Kafka servers. We will:
1. Copy the CA from Kafka to Vault server
2. Import that CA into Vault PKI
3. Configure Vault to issue new certificates using that same CA
4. Setup Terraform to automate certificate management

**This is exactly what you'll do at work!**

---

## STEP 1: Copy Certificates from Kafka to Vault Server

```sh
# SSH into Vault server
ssh cafanwii@10.0.0.19

# On vault-pixie (10.0.0.19):
cd ~

# Ensure directory exists
mkdir -p ~/vault-2026/existing-certs

# Copy CA certificates FROM Kafka (10.0.0.15) TO vault-pixie
# These are the "existing production" certificates we created in Phase 3
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCRoot.cer ~/vault-2026/existing-certs/
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCRoot.key ~/vault-2026/existing-certs/
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCIntermediate.cer ~/vault-2026/existing-certs/
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCIntermediate.key ~/vault-2026/existing-certs/
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/sandbox.crt ~/vault-2026/existing-certs/
scp cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/cacerts.crt ~/vault-2026/existing-certs/

# Verify files copied
ls -la ~/vault-2026/existing-certs/

echo "✅ Certificates copied to vault-pixie"
```

---

## STEP 2: Import Existing CA into Vault PKI

**This is the key step!** We're importing YOUR existing CA into Vault.

```sh
# On vault-pixie
cd ~/vault-2026/existing-certs

# Set Vault environment
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"
vault login $VAULT_TOKEN

# ============================================
# Import Existing Intermediate CA
# ============================================

# Create PEM bundle (private key + certificate)
cat BCBSNCIntermediate.key BCBSNCIntermediate.cer > intermediate-bundle.pem

# Enable PKI secrets engine for Kafka certificates
vault secrets enable -path=pki_int pki
vault secrets tune -max-lease-ttl=43800h pki_int

# Import the existing intermediate CA
# This is YOUR production CA, not a new one!
vault write pki_int/config/ca pem_bundle=@intermediate-bundle.pem

# Configure URLs
vault write pki_int/config/urls \
    issuing_certificates="https://vault.pixiescloud.com/v1/pki_int/ca" \
    crl_distribution_points="https://vault.pixiescloud.com/v1/pki_int/crl"

echo ""
echo "✅ Existing CA imported into Vault"

# ============================================
# Verify the Imported CA
# ============================================

# Get CA certificate from Vault
vault read -field=certificate pki_int/cert/ca > vault-imported-ca.crt

# Compare with original
echo "Original CA from Kafka:"
openssl x509 -in BCBSNCIntermediate.cer -noout -subject -issuer

echo ""
echo "CA now in Vault:"
openssl x509 -in vault-imported-ca.crt -noout -subject -issuer

echo ""
echo " Verification complete - CA successfully imported!"
echo ""
echo "Vault will now issue certificates signed by YOUR existing CA"
```

---

## STEP 3: Create Vault Role to Match Existing Certificates

```sh
# On vault-pixie
cd ~/vault-2026/existing-certs

# Analyze existing certificate structure
echo "Analyzing existing certificate structure..."
openssl x509 -in sandbox.crt -text -noout > existing-cert-details.txt

echo ""
echo "Creating Vault role to match existing certificate structure..."

# Create Vault role matching existing certificate parameters
vault write pki_int/roles/kafka-migration \
    allowed_domains="mainframe,mainframe.local,localhost,*.local,sandbox" \
    allow_bare_domains=true \
    allow_subdomains=true \
    allow_localhost=true \
    allow_ip_sans=true \
    server_flag=true \
    client_flag=true \
    key_type=rsa \
    key_bits=2048 \
    max_ttl="8760h" \
    ttl="8760h"

echo "✅ Vault role configured to match existing certificates"
```

---

## STEP 4: Test Certificate Generation from Vault

**Important:** This certificate will be signed by YOUR imported CA!

```sh
# On vault-pixie (10.0.0.19)
cd ~/vault-2026/existing-certs

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Testing Certificate Generation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Generating test certificate from Vault..."
echo "This will be signed by YOUR imported CA"
echo ""

# Generate test certificate from Vault
vault write -format=json pki_int/issue/kafka-migration \
    common_name="mainframe" \
    ip_sans="10.0.0.15,10.0.0.2,127.0.0.1" \
    alt_names="mainframe.local,localhost" \
    ttl="8760h" > vault-test-cert.json

# Extract components
jq -r '.data.certificate' vault-test-cert.json > vault-mainframe.crt
jq -r '.data.private_key' vault-test-cert.json > vault-mainframe.key
jq -r '.data.ca_chain[]' vault-test-cert.json > vault-ca-chain.crt

# Set permissions
chmod 600 vault-mainframe.key
chmod 644 vault-mainframe.crt vault-ca-chain.crt

echo "✅ Test certificate generated from Vault"

# ============================================
# Compare Certificates (Critical Check!)
# ============================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Certificate Comparison"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "EXISTING CERTIFICATE (from Kafka):"
echo "----------------------------------------"
openssl x509 -in sandbox.crt -noout -subject -issuer -dates
openssl x509 -in sandbox.crt -noout -ext subjectAltName

echo ""
echo "VAULT-GENERATED CERTIFICATE:"
echo "----------------------------------------"
openssl x509 -in vault-mainframe.crt -noout -subject -issuer -dates
openssl x509 -in vault-mainframe.crt -noout -ext subjectAltName

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Key Observation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Notice: BOTH certificates have the same issuer:"
echo "  'Test Intermediate CA'"
echo ""
echo "This means:"
echo "✅ Vault is using YOUR imported CA"
echo "✅ New certs are signed by same CA as existing certs"
echo "✅ All infrastructure will trust Vault-issued certs"
echo ""

# ============================================
# Verification
# ============================================

echo "Verifying certificate chains..."
echo ""

echo "Existing cert verification:"
openssl verify -CAfile cacerts.crt sandbox.crt

echo ""
echo "Vault cert verification:"
# Create complete CA chain for verification
cat BCBSNCIntermediate.cer BCBSNCRoot.cer > complete-ca-chain.crt
openssl verify -CAfile complete-ca-chain.crt vault-mainframe.crt

echo ""
echo "✅ Both certificates verified successfully!"
echo "✅ Both are signed by the SAME CA"
```

---

## STEP 5: Setup SSH Access from Vault to Mainframe

```sh
# On vault-pixie (10.0.0.19)

echo ""
echo "Setting up SSH access for automated deployment..."

# Generate SSH key for deployment
ssh-keygen -t rsa -b 4096 -f ~/.ssh/kafka-deploy -N ""

# Copy public key to mainframe
ssh-copy-id -i ~/.ssh/kafka-deploy.pub cafanwii@10.0.0.15

# Test SSH connection
ssh -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15 "hostname && whoami"

# Should output:
# mainframe
# cafanwii

echo "✅ SSH access configured"
```

---

## STEP 6: Setup Terraform for Automated Deployment

```sh
# On vault-pixie
cd ~/vault-2026
mkdir -p kafka-terraform-cert-automation
cd kafka-terraform-cert-automation

# Create output directory
mkdir -p /home/cafanwii/vault-2026/vault-generated-certs

echo "✅ Directories created"
```

### Create main.tf

```sh
cat > main.tf <<'TERRAFORM_MAIN'
terraform {
  required_providers {
    vault = {
      source  = "hashicorp/vault"
      version = "~> 4.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.9"
    }
  }
}

provider "vault" {
  address = var.vault_address
  token   = var.vault_token
}

# Generate certificate from imported CA
resource "vault_pki_secret_backend_cert" "kafka_cert" {
  backend     = "pki_int"
  name        = "kafka-migration"
  common_name = var.kafka_hostname
  
  ip_sans = var.kafka_ip_sans
  alt_names = var.kafka_alt_names
  ttl = var.cert_ttl
  min_seconds_remaining = var.renewal_threshold
  
  lifecycle {
    create_before_destroy = true
  }
}

resource "local_file" "certificate" {
  content         = vault_pki_secret_backend_cert.kafka_cert.certificate
  filename        = "${var.output_path}/${var.kafka_hostname}.crt"
  file_permission = "0644"
}

resource "local_file" "private_key" {
  content         = vault_pki_secret_backend_cert.kafka_cert.private_key
  filename        = "${var.output_path}/${var.kafka_hostname}.key"
  file_permission = "0600"
}

resource "local_file" "ca_chain" {
  content         = vault_pki_secret_backend_cert.kafka_cert.ca_chain
  filename        = "${var.output_path}/ca-chain.crt"
  file_permission = "0644"
}

resource "local_file" "issuing_ca" {
  content         = vault_pki_secret_backend_cert.kafka_cert.issuing_ca
  filename        = "${var.output_path}/issuing-ca.crt"
  file_permission = "0644"
}

resource "null_resource" "deploy_to_kafka" {
  count = var.kafka_server_host != "" ? 1 : 0
  
  triggers = {
    cert_serial = vault_pki_secret_backend_cert.kafka_cert.serial_number
    cert_expiry = vault_pki_secret_backend_cert.kafka_cert.expiration
  }
  
  provisioner "file" {
    content     = vault_pki_secret_backend_cert.kafka_cert.certificate
    destination = "${var.kafka_cert_path}/${var.kafka_hostname}.crt"
    
    connection {
      type        = "ssh"
      host        = var.kafka_server_host
      user        = var.kafka_server_user
      private_key = file(var.ssh_private_key_path)
    }
  }
  
  provisioner "file" {
    content     = vault_pki_secret_backend_cert.kafka_cert.private_key
    destination = "${var.kafka_cert_path}/${var.kafka_hostname}.key"
    
    connection {
      type        = "ssh"
      host        = var.kafka_server_host
      user        = var.kafka_server_user
      private_key = file(var.ssh_private_key_path)
    }
  }
  
  provisioner "file" {
    content     = vault_pki_secret_backend_cert.kafka_cert.ca_chain
    destination = "${var.kafka_cert_path}/ca-chain.crt"
    
    connection {
      type        = "ssh"
      host        = var.kafka_server_host
      user        = var.kafka_server_user
      private_key = file(var.ssh_private_key_path)
    }
  }
  
  provisioner "remote-exec" {
    inline = [
      "chmod 600 ${var.kafka_cert_path}/${var.kafka_hostname}.key",
      "chmod 644 ${var.kafka_cert_path}/${var.kafka_hostname}.crt",
      "chmod 644 ${var.kafka_cert_path}/ca-chain.crt",
      "echo 'Certificate updated on $(date)' >> ${var.kafka_cert_path}/renewal.log",
      var.restart_command
    ]
    
    connection {
      type        = "ssh"
      host        = var.kafka_server_host
      user        = var.kafka_server_user
      private_key = file(var.ssh_private_key_path)
    }
  }
  
  depends_on = [
    local_file.certificate,
    local_file.private_key,
    local_file.ca_chain
  ]
}

output "certificate_serial" {
  value       = vault_pki_secret_backend_cert.kafka_cert.serial_number
  description = "Certificate serial number"
}

output "certificate_expiration" {
  value       = vault_pki_secret_backend_cert.kafka_cert.expiration
  description = "Certificate expiration timestamp"
}

output "certificate_path" {
  value       = local_file.certificate.filename
  description = "Path to certificate file"
}

output "private_key_path" {
  value       = local_file.private_key.filename
  description = "Path to private key file"
  sensitive   = true
}

output "days_until_expiry" {
  value       = floor((vault_pki_secret_backend_cert.kafka_cert.expiration - time_static.now.unix) / 86400)
  description = "Days until certificate expires"
}

resource "time_static" "now" {}
TERRAFORM_MAIN

echo "✅ main.tf created"
```

### Create variables.tf

```sh
cat > variables.tf <<'TERRAFORM_VARS'
variable "vault_address" {
  description = "Vault server address"
  type        = string
  default     = "https://vault.pixiescloud.com"
}

variable "vault_token" {
  description = "Vault authentication token"
  type        = string
  sensitive   = true
}

variable "kafka_hostname" {
  description = "Kafka server hostname (used as common name)"
  type        = string
  default     = "mainframe"
}

variable "kafka_ip_sans" {
  description = "List of IP addresses for Subject Alternative Names"
  type        = list(string)
  default     = ["127.0.0.1"]
}

variable "kafka_alt_names" {
  description = "List of alternative DNS names"
  type        = list(string)
  default     = ["localhost"]
}

variable "cert_ttl" {
  description = "Certificate TTL (5m for testing, 8760h for production)"
  type        = string
  default     = "5m"
}

variable "renewal_threshold" {
  description = "Renew certificate when this many seconds remain"
  type        = number
  default     = 120
}

variable "output_path" {
  description = "Local path to save certificates"
  type        = string
  default     = "/home/cafanwii/vault-2026/vault-generated-certs"
}

variable "kafka_server_host" {
  description = "Kafka server hostname/IP for deployment"
  type        = string
  default     = ""
}

variable "kafka_server_user" {
  description = "SSH user for Kafka server"
  type        = string
  default     = "cafanwii"
}

variable "kafka_cert_path" {
  description = "Path on Kafka server to deploy certificates"
  type        = string
  default     = "/home/cafanwii/certs/kafka/kafkasandbox"
}

variable "ssh_private_key_path" {
  description = "Path to SSH private key for Kafka server access"
  type        = string
  default     = "~/.ssh/kafka-deploy"
}

variable "restart_command" {
  description = "Command to restart Kafka after certificate renewal"
  type        = string
  default     = "echo 'Deployment complete'"
}
TERRAFORM_VARS

echo "✅ variables.tf created"
```

### Create terraform.tfvars (5-MINUTE CERTIFICATE TESTING)

```sh
cat > terraform.tfvars <<'TERRAFORM_TFVARS'
# ============================================
# Vault Configuration
# ============================================
vault_address = "https://vault.pixiescloud.com"
vault_token   = "hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

# ============================================
# Certificate Configuration - 5 MINUTE TESTING
# ============================================
kafka_hostname = "mainframe"
output_path    = "/home/cafanwii/vault-2026/vault-generated-certs"

kafka_ip_sans = ["10.0.0.15", "10.0.0.2", "127.0.0.1"]
kafka_alt_names = ["mainframe.local", "localhost"]

# 🔥 5-MINUTE CERTIFICATE FOR TESTING AUTOMATIC RENEWAL
cert_ttl = "5m"
renewal_threshold = 120  # Renew when 2 minutes remain

# ============================================
# Remote Deployment to Mainframe
# ============================================
kafka_server_host    = "10.0.0.15"
kafka_server_user    = "cafanwii"
kafka_cert_path      = "/home/cafanwii/certs/kafka/kafkasandbox"
ssh_private_key_path = "~/.ssh/kafka-deploy"
restart_command = "echo 'Certificate renewed at $(date)' | tee -a /home/cafanwii/certs/kafka/kafkasandbox/vault-deployment.log"
TERRAFORM_TFVARS

chmod 600 terraform.tfvars

echo "✅ terraform.tfvars created with 5-minute certificate settings"
```

---

## STEP 7: Initialize and Deploy Terraform

```sh
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Deploying First Certificate"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Initialize Terraform
terraform init

# Review plan
terraform plan

# Deploy!
terraform apply -auto-approve

echo ""
echo "✅ First certificate deployed!"
echo ""
echo "This certificate was issued by Vault"
echo "but signed by YOUR imported CA!"
```

---

## Expected Output

```
Apply complete! Resources: 7 added, 0 changed, 0 destroyed.

Outputs:
certificate_expiration = <timestamp>
certificate_path = "/home/cafanwii/vault-2026/vault-generated-certs/mainframe.crt"
certificate_serial = "xx:xx:xx:xx:..."
days_until_expiry = 0
```

**Note:** `days_until_expiry = 0` is correct for 5-minute certificates!

---

## 🎯 What Just Happened (Production Perspective)

```
1. You created "existing" certificates on Kafka (Phase 3)
   └─ These simulate your current production certs

2. You imported that CA into Vault (Phase 4, Step 2)
   └─ Vault now has YOUR production CA

3. Vault generated a NEW certificate (Phase 4, Step 7)
   └─ Signed by YOUR imported CA
   └─ Deployed to Kafka server
   └─ Sits alongside existing cert

4. Both certificates trust the same CA
   └─ Existing cert: sandbox.crt (manual)
   └─ Vault cert: mainframe.crt (automated)
   └─ Same issuer: "Test Intermediate CA"
```

---

## Next Step

Run Phase 5 (5-watch-renewal.md) to watch automatic renewal every 3 minutes!
