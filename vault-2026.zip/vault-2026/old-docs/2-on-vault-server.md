# Phase 2: Vault Server Setup (Part 1) - Prepare for CA Import

## Architecture - True Production Simulation
```
┌─────────────────────────────────┐
│  Kafka Server (10.0.0.15)       │
│  HAS EXISTING CA:               │
│  - BCBSNCRoot.cer               │
│  - BCBSNCIntermediate.cer       │
│  - sandbox.crt (server cert)    │
│                                 │
│  We will IMPORT this CA         │
│  into Vault (not create new)    │
└─────────────────────────────────┘
           │
           │ Copy CA certificates
           ▼
┌─────────────────────────────────┐
│  Vault Server (10.0.0.19)       │
│  Will IMPORT existing CA        │
│  (Not create new CA)            │
│                                 │
│  Then issue new certs using     │
│  the imported CA                │
└─────────────────────────────────┘
```

## 🎯 Production Scenario

**At your job, you will:**
1. Get existing CA from Kafka servers (or PKI team)
2. Import that CA into Vault
3. Vault issues new certificates using YOUR existing CA
4. All new certs trusted by existing infrastructure

**We are NOT creating a new CA in Vault!**

---

## 🧹 STEP 1: Complete Teardown (Clean Slate)

```sh
# SSH to vault-pixie
ssh cafanwii@10.0.0.19

# Set Vault environment
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

# Remove existing PKI engines (if any)
vault secrets disable pki_root 2>/dev/null || true
vault secrets disable pki_int 2>/dev/null || true
vault secrets disable pki_kafka 2>/dev/null || true

# Clean up directories
rm -rf ~/vault-2026/existing-certs
rm -rf ~/vault-2026/vault-generated-certs
rm -rf ~/vault-2026/kafka-terraform-cert-automation

# Remove SSH keys
rm -f ~/.ssh/kafka-deploy ~/.ssh/kafka-deploy.pub

# Remove from known_hosts if needed
ssh-keygen -R 10.0.0.15 2>/dev/null || true

echo "✅ Vault server cleaned up - ready for fresh start"
```

---

## 🚀 STEP 2: Prepare Vault for CA Import

We're NOT creating a CA here. We're just preparing directories and verifying Vault is ready.

```sh
# On vault-pixie (10.0.0.19)
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"
vault login $VAULT_TOKEN

# Verify Vault is accessible
vault status

echo "✅ Vault is ready"

# ============================================
# Create Directory for Incoming Certificates
# ============================================

mkdir -p ~/vault-2026/existing-certs

echo "✅ Directory created for CA import"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Vault server is ready"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Next Steps:"
echo "1. Run Phase 3 (3-on-kafka-machine.md)"
echo "   → Create 'existing' production certificates on Kafka"
echo ""
echo "2. Then return to Phase 4 (4-on-vault-server-part-2.md)"
echo "   → Import those certificates into Vault"
echo ""
echo "This simulates your production scenario where:"
echo "- Kafka already has certificates (Phase 3)"
echo "- You import that CA into Vault (Phase 4)"
echo "- Vault manages new certificates using existing CA"
```

---

## 🎓 Production Context

**What we're simulating:**

In production at your company:
- Kafka servers already have certificates issued by company PKI
- Those certificates are signed by `BCBSNCIntermediate`
- `BCBSNCIntermediate` is signed by `BCBSNCRoot`

**What you'll do:**
- Get the Intermediate CA from PKI team (or extract from Kafka)
- Import into Vault
- Vault issues new certificates signed by same CA
- No trust issues - everything uses existing CA chain

**What we're NOT doing:**
- ❌ Creating new Root CA in Vault
- ❌ Creating new Intermediate CA in Vault
- ❌ Asking clients to trust new CA

**What we ARE doing:**
- ✅ Using existing production CA
- ✅ Importing existing CA into Vault
- ✅ Letting Vault automate certificate issuance
- ✅ Maintaining existing trust relationships

---

## ✅ Verification

```sh
# Verify Vault is ready
vault status

# Verify directory exists
ls -la ~/vault-2026/existing-certs/

# Should show empty directory, ready for certificates

echo "✅ Vault server prepared for CA import!"
echo ""
echo "Next: Run Phase 3 to create 'existing' certificates on Kafka server"
```

---

## 📋 Summary

**This phase:**
- ✅ Cleaned up any previous setup
- ✅ Verified Vault is accessible
- ✅ Created directory for incoming CA certificates
- ✅ Did NOT create any new CA (production-realistic)

**Next phase:**
- Go to Kafka server (Phase 3)
- Create "existing" production certificates
- This simulates what you already have at work

**Then:**
- Return to Vault server (Phase 4)
- Import the Kafka CA
- Configure Terraform automation
