## What Each Team Can Do:
# Vault Team Permissions Setup Guide

## Overview

This Terraform configuration sets up role-based access control (RBAC) for 4 teams:

| Team            | Permissions                                    | Use Case                          |
|-----------------|------------------------------------------------|-----------------------------------|
| **Administrators** | Full access to everything                   | Vault management & administration |
| **Middleware**     | PKI certificates + Secrets management       | Certificate automation, secrets   |
| **Security**       | Read-only access to view environment        | Auditing, compliance, monitoring  |
| **HCL**            | Full access to secrets only                 | Application secrets, configs      |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│ Vault Server                                                     │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Authentication Methods                                   │   │
│  │  ├── userpass (for humans)                              │   │
│  │  └── approle (for applications/automation)              │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Policies (what users can do)                            │   │
│  │  ├── administrators-policy (full access)                │   │
│  │  ├── middleware-policy (PKI + secrets)                  │   │
│  │  ├── security-policy (read-only)                        │   │
│  │  └── hcl-policy (secrets only)                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Users                                                    │   │
│  │  ├── admin1, admin2 → administrators-policy             │   │
│  │  ├── middleware1, middleware2 → middleware-policy       │   │
│  │  ├── security1, security2 → security-policy             │   │
│  │  └── hcl1, hcl2 → hcl-policy                            │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Setup Instructions

### Step 1: Create Directory

### Step 2: Copy Terraform Files

Upload these files:
1. `main.tf` (vault-permissions-main.tf)
2. `variables.tf` (vault-permissions-variables.tf)
3. `terraform.tfvars` (vault-permissions-terraform.tfvars)

### Step 3: Edit terraform.tfvars

**IMPORTANT:** Change all default passwords!

```hcl
admin_passwords = {
  admin1 = "YourSecureAdminPassword1!"
  admin2 = "YourSecureAdminPassword2!"
}

middleware_users = {
  middleware1 = "YourMiddlewarePassword1!"
  # ... add more users
}

security_users = {
  security1 = "YourSecurityPassword1!"
  # ... add more users
}

hcl_users = {
  hcl1 = "YourHCLPassword1!"
  # ... add more users
}
```

### Step 4: Initialize and Apply

```bash
cd ~/vault-2026/vault-permissions

# Initialize Terraform
terraform init

# Preview what will be created
terraform plan

# Apply the configuration
terraform apply
```

### Step 5: Review Outputs

```bash
# See all policies created
terraform output policies_created

# See AppRole IDs (for applications)
terraform output approle_role_ids

# See login instructions
terraform output user_login_instructions
```
### 2. Check What Got Created

```bash
# Login as root/admin first
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"
vault login $VAULT_TOKEN

# List all policies
vault policy list
# Should see: administrators-policy, middleware-policy, security-policy, hcl-policy

# List auth methods
vault auth list
# Should see: userpass, approle, ldap

# List secret engines
vault secrets list
# Should see: middlewaresecret

# List userpass users
vault list auth/userpass/users
# Should see: admin1, admin2, middleware1, middleware2, middleware3, security1, security2, auditor1, hcl1, hcl2, hcl_dev1, hcl_dev2
```

---

## 🔐 Test 1: Administrator Access (Full Access)

### Login as Administrator

```bash
vault login -method=userpass username=admin1
# Enter password from terraform.tfvars
```

### Test Full Access ✅

```bash
# 1. Test policy management (admin only)
vault policy list
# ✅ Should work

vault policy read middleware-policy
# ✅ Should work

# 2. Test PKI access
vault list pki_int/certs
# ✅ Should work

vault read pki_int/cert/ca
# ✅ Should work

# 3. Test secrets read
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work

# 4. Test secrets write
vault kv put middlewaresecret/admin-test/test message="Admin can write"
# ✅ Should work

# 5. Test auth management
vault auth list
# ✅ Should work

# 6. Test user management
vault list auth/userpass/users
# ✅ Should work

# 7. Test issuing certificates
vault write pki_int/issue/kafka-migration \
  common_name="admin-test.example.com" \
  ttl="24h"
# ✅ Should work
```

### Expected Results:
- **ALL commands should succeed** ✅
- Administrators have full access to everything

---

## 🔧 Test 2: Middleware Access (PKI + Secrets)

### Login as Middleware User

```bash
vault login -method=userpass username=middleware1
# Enter password
```

### Test PKI Access ✅

```bash
# 1. List certificates
vault list pki_int/certs
# ✅ Should work

# 2. Read CA certificate
vault read pki_int/cert/ca
# ✅ Should work

# 3. Issue a certificate
vault write pki_int/issue/kafka-migration \
  common_name="middleware-test.example.com" \
  ttl="24h"
# ✅ Should work - Returns certificate, private key, CA chain

# 4. Read issued certificate details
vault read pki_int/cert/$(vault list -format=json pki_int/certs | jq -r '.[0]')
# ✅ Should work
```

### Test Secrets Access ✅

```bash
# 1. Read existing secrets
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work - Shows: cn-root: faidev2012

vault kv get middlewaresecret/servers/lxdbd2p101
# ✅ Should work

# 2. Write new secrets
vault kv put middlewaresecret/middleware-team/app1 \
  username="appuser" \
  password="apppass"
# ✅ Should work

# 3. Update secrets
vault kv put middlewaresecret/middleware-team/app1 \
  username="appuser" \
  password="newpass"
# ✅ Should work

# 4. Delete secrets
vault kv delete middlewaresecret/middleware-team/app1
# ✅ Should work

# 5. List secret paths
vault list middlewaresecret/
# ✅ Should work
```

### Test Admin Access ❌ (Should Fail)

```bash
# 1. Try to list policies
vault policy list
# ❌ Should FAIL with "permission denied"

# 2. Try to manage users
vault list auth/userpass/users
# ❌ Should FAIL with "permission denied"

# 3. Try to view auth methods
vault auth list
# ❌ Should FAIL with "permission denied"
```

### Expected Results:
- ✅ **PKI operations work**
- ✅ **Secrets read/write work**
- ❌ **Admin operations FAIL** (correct!)

---

## 👁️ Test 3: Security Access (Read-Only)

### Login as Security User

```bash
vault login -method=userpass username=security1
# Enter password
```

### Test Read Access ✅

```bash
# 1. Read PKI certificates
vault list pki_int/certs
# ✅ Should work

vault read pki_int/cert/ca
# ✅ Should work

# 2. Read secrets
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work

vault kv get middlewaresecret/servers/lxdbd2p101
# ✅ Should work

# 3. List secret paths
vault list middlewaresecret/
# ✅ Should work

# 4. View policies
vault policy list
# ✅ Should work

vault policy read middleware-policy
# ✅ Should work

# 5. View auth methods
vault auth list
# ✅ Should work

# 6. View secret engines
vault secrets list
# ✅ Should work
```

### Test Write Access ❌ (Should Fail)

```bash
# 1. Try to write secrets
vault kv put middlewaresecret/security-test/test message="Should fail"
# ❌ Should FAIL with "permission denied"

# 2. Try to issue certificates
vault write pki_int/issue/kafka-migration \
  common_name="security-test.example.com" \
  ttl="24h"
# ❌ Should FAIL with "permission denied"

# 3. Try to delete secrets
vault kv delete middlewaresecret/IBM-LDAP-Directory/dev
# ❌ Should FAIL with "permission denied"

# 4. Try to create users
vault write auth/userpass/users/testuser password="test123"
# ❌ Should FAIL with "permission denied"
```

### Expected Results:
- ✅ **All READ operations work**
- ❌ **All WRITE operations FAIL** (correct!)

---

## 📦 Test 4: HCL Access (Secrets Only)

### Login as HCL User

```bash
vault login -method=userpass username=hcl1
# Enter password
```

### Test Secrets Access ✅

```bash
# 1. Read secrets
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work

vault kv get middlewaresecret/servers/lxdbd2p101
# ✅ Should work

# 2. Write secrets
vault kv put middlewaresecret/hcl-team/app1 \
  api_key="abc123" \
  database="proddb"
# ✅ Should work

# 3. Update secrets
vault kv put middlewaresecret/hcl-team/app1 \
  api_key="xyz789" \
  database="proddb"
# ✅ Should work

# 4. List paths
vault list middlewaresecret/
# ✅ Should work

# 5. Delete secrets
vault kv delete middlewaresecret/hcl-team/app1
# ✅ Should work
```

### Test PKI Access ❌ (Should Fail)

```bash
# 1. Try to list certificates
vault list pki_int/certs
# ❌ Should FAIL with "permission denied"

# 2. Try to read CA
vault read pki_int/cert/ca
# ❌ Should FAIL with "permission denied"

# 3. Try to issue certificate
vault write pki_int/issue/kafka-migration \
  common_name="hcl-test.example.com" \
  ttl="24h"
# ❌ Should FAIL with "permission denied"
```

### Test Admin Access ❌ (Should Fail)

```bash
# 1. Try to list policies
vault policy list
# ❌ Should FAIL with "permission denied"

# 2. Try to view users
vault list auth/userpass/users
# ❌ Should FAIL with "permission denied"
```

### Expected Results:
- ✅ **Secrets operations work**
- ❌ **PKI operations FAIL** (correct!)
- ❌ **Admin operations FAIL** (correct!)

---

## 🌐 Test 5: LDAP Authentication

### Prerequisites
Make sure these AD groups exist:
- `BAU_admin_team`
- `BAU_middleware_team`
- `BAU_security_team`
- `BAU_hcl_team`

### Test LDAP Login

```bash
# Test with an AD user in BAU_middleware_team
vault login -method=ldap username=<your_ad_username>
# Enter your AD password

# Check what policies you got
vault token lookup
# Should show: policies = ["default", "middleware-policy"]

# Test middleware access
vault list pki_int/certs
# ✅ Should work

vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work
```

### Verify LDAP Group Mappings

```bash
# Login as admin first
vault login -method=userpass username=admin1

# Check LDAP group mappings
vault read auth/ldap/groups/BAU_middleware_team
# Should show: policies = ["middleware-policy"]

vault read auth/ldap/groups/BAU_security_team
# Should show: policies = ["security-policy"]

vault read auth/ldap/groups/BAU_hcl_team
# Should show: policies = ["hcl-policy"]

vault read auth/ldap/groups/BAU_admin_team
# Should show: policies = ["administrators-policy"]
```

---

## 🤖 Test 6: AppRole Authentication

### Test Middleware AppRole

```bash
# Login as admin
vault login -method=userpass username=admin1

# Get the Role ID (from Terraform output)
terraform output -raw approle_role_ids
# Note the middleware_app role_id

# Generate a Secret ID
vault write -f auth/approle/role/middleware-app/secret-id
# Note the secret_id from output

# Login with AppRole
vault write auth/approle/login \
  role_id="<role_id_from_output>" \
  secret_id="<secret_id_from_above>"
# Returns a client_token

# Use the token
export VAULT_TOKEN="<client_token_from_above>"

# Test middleware access
vault list pki_int/certs
# ✅ Should work

vault kv get middlewaresecret/IBM-LDAP-Directory/dev
# ✅ Should work

# Test admin access (should fail)
vault policy list
# ❌ Should FAIL
```

### Test HCL AppRole

```bash
# Login as admin
vault login -method=userpass username=admin1

# Generate Secret ID for HCL app
vault write -f auth/approle/role/hcl-app/secret-id

# Login with HCL AppRole
vault write auth/approle/login \
  role_id="<hcl_role_id>" \
  secret_id="<secret_id>"

# Use the token
export VAULT_TOKEN="<client_token>"

# Test secrets access
vault kv get middlewaresecret/servers/lxdbd2p101
# ✅ Should work

# Test PKI access (should fail)
vault list pki_int/certs
# ❌ Should FAIL
```

---

## 📊 Test 7: Existing Secrets

### Verify All Existing Secrets Are Accessible

```bash
# Login as middleware user
vault login -method=userpass username=middleware1

# Test all existing secret paths
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
vault kv get middlewaresecret/IBM-LDAP-Directory/qa
vault kv get middlewaresecret/IBM-LDAP-Directory/pstage
vault kv get middlewaresecret/IBM-LDAP-Directory/prod

vault kv get middlewaresecret/servers/lxdbd2p101
vault kv get middlewaresecret/servers/lxdbd2p102

vault kv get middlewaresecret/nwfDataMgmt/DEV
vault kv get middlewaresecret/nwfDataMgmt/QA
vault kv get middlewaresecret/nwfDataMgmt/Pstage
vault kv get middlewaresecret/nwfDataMgmt/prod

vault kv get middlewaresecret/aix/ddcads101

# All should return the secrets ✅
```

---

## 🔍 Test 8: Audit & Monitoring

### Check Token Info

```bash
# Login as any user
vault login -method=userpass username=middleware1

# View your token details
vault token lookup
# Shows: policies, ttl, renewable, etc.

# View capabilities on a path
vault token capabilities middlewaresecret/IBM-LDAP-Directory/dev
# Should show: ["create", "delete", "list", "read", "update"]

vault token capabilities pki_int/certs
# Should show: ["create", "delete", "list", "read", "update"]

vault token capabilities sys/policies/acl
# Should show: ["deny"] (middleware can't access)
```

### Enable Audit Logging (Optional)

```bash
# Login as admin
vault login -method=userpass username=admin1

# Enable file audit
vault audit enable file file_path=/var/log/vault_audit.log

# Test it
vault kv get middlewaresecret/IBM-LDAP-Directory/dev

# Check log
sudo tail -f /var/log/vault_audit.log
# Should show the request
```

---

## ✅ Success Criteria Summary

| Test | Team | Expected Result |
|------|------|----------------|
| **PKI - List Certs** | Admin ✅ | Success |
| | Middleware ✅ | Success |
| | Security ✅ | Success |
| | HCL ❌ | Fail |
| **PKI - Issue Certs** | Admin ✅ | Success |
| | Middleware ✅ | Success |
| | Security ❌ | Fail |
| | HCL ❌ | Fail |
| **Secrets - Read** | Admin ✅ | Success |
| | Middleware ✅ | Success |
| | Security ✅ | Success |
| | HCL ✅ | Success |
| **Secrets - Write** | Admin ✅ | Success |
| | Middleware ✅ | Success |
| | Security ❌ | Fail |
| | HCL ✅ | Success |
| **Admin - Policies** | Admin ✅ | Success |
| | Middleware ❌ | Fail |
| | Security ✅ | Success (read-only) |
| | HCL ❌ | Fail |
| **Admin - Users** | Admin ✅ | Success |
| | Middleware ❌ | Fail |
| | Security ❌ | Fail |
| | HCL ❌ | Fail |

---

## 🐛 Troubleshooting

### User can't login

```bash
# Check if user exists
vault list auth/userpass/users

# Check user details
vault read auth/userpass/users/middleware1

# Reset password
vault write auth/userpass/users/middleware1/password password="newpass"
```

### Permission denied errors

```bash
# Check what policies user has
vault token lookup

# Check what policy allows
vault policy read middleware-policy

# Check capabilities on specific path
vault token capabilities middlewaresecret/IBM-LDAP-Directory/dev
```

### LDAP not working

```bash
# Test LDAP connection
vault read auth/ldap/config

# Check LDAP group mapping
vault read auth/ldap/groups/BAU_middleware_team

# Test LDAP bind
vault write auth/ldap/login/testuser password="testpass"
```

### Secrets not accessible

```bash
# Check if secret engine exists
vault secrets list

# Check if secret exists
vault kv get middlewaresecret/IBM-LDAP-Directory/dev

# Check path format (no trailing slash)
# ✅ CORRECT: middlewaresecret/path
# ❌ WRONG: middlewaresecret/path/
```

---

## 📋 Quick Test Script

Save this as `test-vault-permissions.sh`:

```bash
#!/bin/bash

echo "=== Vault Permissions Test ==="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

test_command() {
  local description=$1
  local command=$2
  local should_succeed=$3
  
  echo -n "Testing: $description... "
  
  if eval "$command" &>/dev/null; then
    if [ "$should_succeed" = "yes" ]; then
      echo -e "${GREEN}✅ PASS${NC}"
    else
      echo -e "${RED}❌ FAIL (should have been denied)${NC}"
    fi
  else
    if [ "$should_succeed" = "no" ]; then
      echo -e "${GREEN}✅ PASS (correctly denied)${NC}"
    else
      echo -e "${RED}❌ FAIL (should have succeeded)${NC}"
    fi
  fi
}

# Test Middleware User
echo "=== Testing Middleware User ==="
vault login -method=userpass username=middleware1 password="<password>" &>/dev/null

test_command "List PKI certs" "vault list pki_int/certs" "yes"
test_command "Read secret" "vault kv get middlewaresecret/IBM-LDAP-Directory/dev" "yes"
test_command "Write secret" "vault kv put middlewaresecret/test/temp value=test" "yes"
test_command "List policies (should fail)" "vault policy list" "no"

echo ""
echo "=== Testing Security User ==="
vault login -method=userpass username=security1 password="<password>" &>/dev/null

test_command "Read secret" "vault kv get middlewaresecret/IBM-LDAP-Directory/dev" "yes"
test_command "List policies" "vault policy list" "yes"
test_command "Write secret (should fail)" "vault kv put middlewaresecret/test/temp value=test" "no"

echo ""
echo "=== Testing HCL User ==="
vault login -method=userpass username=hcl1 password="<password>" &>/dev/null

test_command "Read secret" "vault kv get middlewaresecret/IBM-LDAP-Directory/dev" "yes"
test_command "Write secret" "vault kv put middlewaresecret/test/temp value=test" "yes"
test_command "List PKI (should fail)" "vault list pki_int/certs" "no"

echo ""
echo "=== All Tests Complete ==="
```

Run it:
```bash
chmod +x test-vault-permissions.sh
./test-vault-permissions.sh
```

---

**Your Vault is ready for production when all tests pass!** 🎉
