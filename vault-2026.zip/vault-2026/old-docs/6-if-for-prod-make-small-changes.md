# On vault-pixie
cd ~/vault-2026/kafka-terraform-cert-automation

# 1. Update to production settings
cat > terraform.tfvars <<'EOF'
vault_address = "https://vault.pixiescloud.com"
vault_token   = "hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

kafka_hostname = "mainframe"
output_path    = "/home/cafanwii/vault-2026/vault-generated-certs"

kafka_ip_sans = ["10.0.0.15", "10.0.0.2", "127.0.0.1"]
kafka_alt_names = ["mainframe.local", "localhost"]

# PRODUCTION SETTINGS
cert_ttl = "8760h"              # 1 year
renewal_threshold = 604800      # Renew when 7 days remain (604800 seconds)

kafka_server_host    = "10.0.0.15"
kafka_server_user    = "cafanwii"
kafka_cert_path      = "/home/cafanwii/certs/kafka/kafkasandbox"
ssh_private_key_path = "~/.ssh/kafka-deploy"
restart_command = "echo \"Certificate renewed at $(date)\" >> /home/cafanwii/certs/kafka/kafkasandbox/vault-deployment.log"
EOF

# 2. Apply production certificate
terraform apply -replace=vault_pki_secret_backend_cert.kafka_cert -auto-approve

# 3. Create log directory
sudo mkdir -p /var/log
sudo touch /var/log/kafka-cert-renewal.log
sudo chown cafanwii:cafanwii /var/log/kafka-cert-renewal.log

# 4. Set up cron job
crontab -e

# Add this line (runs daily at 2 AM):
0 2 * * * cd /home/cafanwii/vault-2026/kafka-terraform-cert-automation && /usr/bin/terraform apply -auto-approve >> /var/log/kafka-cert-renewal.log 2>&1

# 5. Verify cron job was added
crontab -l
```

## How It Works in Production:
```
┌─────────────────────────────────────────────────────────────┐
│ vault-pixie (Vault Server)                                   │
│                                                              │
│  ┌──────────────┐     Daily at 2 AM                         │
│  │  cron job    │─────────────────┐                         │
│  └──────────────┘                 │                         │
│                                    ▼                         │
│  ┌─────────────────────────────────────────┐                │
│  │ terraform apply -auto-approve           │                │
│  │ - Checks cert expiry                    │                │
│  │ - If < 7 days remaining → Renew         │                │
│  │ - Generate new cert from Vault          │                │
│  │ - Deploy to mainframe via SSH           │                │
│  └─────────────────────────────────────────┘                │
│                     │                                        │
└─────────────────────┼────────────────────────────────────────┘
                      │ SSH
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ mainframe (Kafka Server - 10.0.0.15)                        │
│                                                              │
│  ~/certs/kafka/kafkasandbox/                                │
│    ├── mainframe.crt    ← Updated                           │
│    ├── mainframe.key    ← Updated                           │
│    ├── ca-chain.crt     ← Updated                           │
│    └── vault-deployment.log ← Timestamped                   │
└─────────────────────────────────────────────────────────────┘