#!/bin/bash

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "=========================================="
echo "🔄 CERTIFICATE AUTO-RENEWAL MONITOR"
echo "=========================================="
echo ""
echo "Certificate Settings:"
echo "  TTL: 5 minutes"
echo "  Renewal threshold: 2 minutes remaining"
echo "  Expected: Renewal after 3 minutes"
echo ""
echo "Monitoring starts now..."
echo "Checking every 30 seconds..."
echo "=========================================="
echo ""

# Get initial serial
cd ~/vault-2026/kafka-terraform-cert-automation
PREV_SERIAL=$(terraform output -raw certificate_serial 2>/dev/null || echo "none")
START_TIME=$(date +%s)

echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} Initial certificate serial: $PREV_SERIAL"
echo ""

RENEWAL_COUNT=0

while true; do
    CURRENT_TIME=$(date +%s)
    ELAPSED=$((CURRENT_TIME - START_TIME))
    MINUTES=$((ELAPSED / 60))
    SECONDS=$((ELAPSED % 60))
    
    # Run terraform apply silently
    terraform apply -auto-approve > /tmp/terraform-apply.log 2>&1
    
    # Get new serial
    NEW_SERIAL=$(terraform output -raw certificate_serial 2>/dev/null || echo "none")
    
    # Check if renewed
    if [ "$PREV_SERIAL" != "$NEW_SERIAL" ]; then
        RENEWAL_COUNT=$((RENEWAL_COUNT + 1))
        echo ""
        echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${GREEN}║  🎉 CERTIFICATE RENEWAL #$RENEWAL_COUNT DETECTED!                          ║${NC}"
        echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
        echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} Time elapsed: ${MINUTES}m ${SECONDS}s"
        echo "   Old serial: $PREV_SERIAL"
        echo "   New serial: $NEW_SERIAL"
        echo ""
        
        # Show deployment on mainframe
        echo "Deployment log from mainframe:"
        ssh -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15 "tail -5 ~/certs/kafka/kafkasandbox/vault-deployment.log" 2>/dev/null || echo "   (Could not fetch log)"
        
        echo ""
        echo -e "${GREEN}✅ Certificate successfully renewed and deployed!${NC}"
        echo "=========================================="
        echo ""
        
        PREV_SERIAL=$NEW_SERIAL
        START_TIME=$(date +%s)  # Reset timer
    else
        echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} ⏳ No renewal needed yet (elapsed: ${MINUTES}m ${SECONDS}s, serial: ${NEW_SERIAL:0:20}...)"
    fi
    
    # Show time until expiry
    DAYS=$(terraform output -raw days_until_expiry 2>/dev/null || echo "0")
    EXPIRY=$(terraform output -raw certificate_expiration 2>/dev/null || echo "0")
    if [ "$EXPIRY" != "0" ]; then
        NOW=$(date +%s)
        REMAINING=$((EXPIRY - NOW))
        if [ $REMAINING -gt 0 ]; then
            REMAINING_MIN=$((REMAINING / 60))
            REMAINING_SEC=$((REMAINING % 60))
            echo "   Time until expiry: ${REMAINING_MIN}m ${REMAINING_SEC}s"
        fi
    fi
    
    # Sleep 30 seconds
    sleep 30
done
