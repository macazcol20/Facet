# HashiCorp Vault - Complete Installation & Configuration Guide

**Document Version:** 2.0  
**Last Updated:** January 18, 2026  
**Server:** vault-pixie (10.0.0.19)  
---

## Table of Contents

1. [Directory Structure](#directory-structure)
2. [Phase 1: Vault Installation](#phase-1-vault-installation)
3. [Phase 2: Team-Based Access Control (IAM)](#phase-2-team-based-access-control)
4. [Phase 3: Certificate Automation](#phase-3-certificate-automation)
5. [Verification & Testing](#verification-testing)
6. [Maintenance & Operations](#maintenance-operations)

---

## Directory Structure

```
/home/cafanwii/vault-2026/
├── 1-installing-vault-ansible/          # Vault installation via Ansible
│   ├── hosts.ini                        # Ansible inventory
│   ├── playbook.yml                     # Vault installation playbook
│   └── playbook-reset.yml               # Vault reset/uninstall playbook
│
├── 2-terraformIAM/                      # Team permissions & access control
│   ├── main.tf                          # Main Terraform configuration
│   ├── policies.tf                      # Policy loader
│   ├── provider.tf                      # Vault provider config
│   ├── variables.tf                     # Variable definitions
│   ├── terraform.tfvars                 # Configuration values (passwords)
│   ├── secrets.tf                       # Middleware secrets
│   ├── policies/                        # Team policy files
│   │   ├── administrators-policy.hcl    # Full access
│   │   ├── middleware-policy.hcl        # PKI + Secrets
│   │   ├── security-policy.hcl          # Read-only
│   │   └── hcl-policy.hcl               # Secrets only
│   └── terraform.tfstate                # Terraform state
│
└── 3-cert-automation/                   # PKI certificate automation
    ├── existing-certs/                  # Imported CA certificates
    │   ├── BCBSNCRoot.cer               # Root CA (imported)
    │   ├── BCBSNCIntermediate.cer       # Intermediate CA (imported)
    │   └── *.crt, *.key                 # Various cert files
    │
    ├── kafka-terraform-cert-automation/ # Certificate automation
    │   ├── main.tf                      # Cert generation config
    │   ├── variables.tf                 # Variables
    │   ├── terraform.tfvars             # Configuration
    │   ├── watch-renewal.sh             # Monitoring script
    │   └── terraform.tfstate            # State
    │
    └── vault-generated-certs/           # Generated certificates
        ├── mainframe.crt                # Server certificate
        ├── mainframe.key                # Private key
        ├── ca-chain.crt                 # CA chain
        └── issuing-ca.crt               # Issuing CA
```

---

## Phase 1: Vault Installation

### Location
```bash
cd /home/cafanwii/vault-2026/1-installing-vault-ansible/
```

### Files
- `hosts.ini` - Ansible inventory file
- `playbook.yml` - Vault installation playbook
- `playbook-reset.yml` - Vault uninstall/reset playbook

### Installation Steps

```bash
# Navigate to installation directory
cd ~/vault-2026/1-installing-vault-ansible/

# Install Vault using Ansible
ansible-playbook -i hosts.ini playbook.yml

# Verify installation
vault version
vault status
```

### Reset/Uninstall (if needed)

```bash
cd ~/vault-2026/1-installing-vault-ansible/
ansible-playbook -i hosts.ini playbook-reset.yml
```

---

## Phase 2: Team-Based Access Control

### Location
```bash
cd /home/cafanwii/vault-2026/2-terraformIAM/
```

### Files Overview

| File | Purpose |
|------|---------|
| `main.tf` | Core configuration - auth methods, users, LDAP |
| `policies.tf` | Loads policy files from `policies/` directory |
| `provider.tf` | Vault provider configuration |
| `variables.tf` | Variable definitions |
| `terraform.tfvars` | **YOUR VALUES** - passwords, LDAP settings |
| `secrets.tf` | Middleware secrets (IBM LDAP, servers, etc.) |
| `policies/*.hcl` | Individual team policy files |

### Setup Steps

#### 1. Navigate to Directory

```bash
cd ~/vault-2026/2-terraformIAM/
```

#### 2. Edit Configuration

```bash
# Edit terraform.tfvars - UPDATE PASSWORDS!
nano terraform.tfvars
```

**Example terraform.tfvars:**
```hcl
vault_address = "https://vault.pixiescloud.com"
vault_token   = "hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

admin_passwords = {
  admin1 = "YourStrongPassword1!"
  admin2 = "YourStrongPassword2!"
}

middleware_users = {
  middleware1 = "MiddlewarePass1!"
  middleware2 = "MiddlewarePass2!"
  middleware3 = "MiddlewarePass3!"
}

security_users = {
  security1 = "SecurityPass1!"
  security2 = "SecurityPass2!"
  auditor1  = "AuditorPass1!"
}

hcl_users = {
  hcl1     = "HCLPass1!"
  hcl2     = "HCLPass2!"
  hcl_dev1 = "HCLDevPass1!"
  hcl_dev2 = "HCLDevPass2!"
}

ldap_bindpass = "YourLDAPBindPassword"
```

#### 3. Initialize and Deploy

```bash
# Initialize Terraform
terraform init

# Preview changes
terraform plan

# Apply configuration
terraform apply
```

#### 4. Verify Deployment

```bash
# Check created policies
vault policy list

# Check users
vault list auth/userpass/users

# Check auth methods
vault auth list

# Check secrets engine
vault secrets list
```

### Policy Files

All policies are in `~/vault-2026/2-terraformIAM/policies/`:

```bash
# View a policy
cat ~/vault-2026/2-terraformIAM/policies/middleware-policy.hcl

# Or via Vault
vault policy read middleware-policy
```

### Testing Access

```bash
# Test middleware user
vault login -method=userpass username=middleware1
vault list pki_int/certs
vault kv get middlewaresecret/IBM-LDAP-Directory/dev

# Test security user (read-only)
vault login -method=userpass username=security1
vault kv get middlewaresecret/IBM-LDAP-Directory/dev
vault policy list

# Test HCL user
vault login -method=userpass username=hcl1
vault kv get middlewaresecret/servers/lxdbd2p101
```

---

## Phase 3: Certificate Automation

### Location
```bash
cd /home/cafanwii/vault-2026/3-cert-automation/
```

### Step-by-Step Documentation Files

Follow these in order:

1. **2-on-vault-server.md** - Prepare Vault server
2. **3-on-kafka-machine.md** - Create existing certificates on Kafka server
3. **4-on-vault-server.md** - Import CA and configure automation
4. **5-watch-renewal.md** - Monitor automatic renewal
5. **6-if-for-prod-make-small-changes.md** - Production configuration

### Quick Setup

#### Step 1: Prepare Vault Server

```bash
cd ~/vault-2026/3-cert-automation/

# Create directories
mkdir -p existing-certs
mkdir -p kafka-terraform-cert-automation
mkdir -p vault-generated-certs

# Set Vault environment
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"
vault login $VAULT_TOKEN
```

#### Step 2: Import CA Certificates

```bash
# Copy CA certificates from Kafka server
cd ~/vault-2026/3-cert-automation/existing-certs/

scp -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCRoot.cer .
scp -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCIntermediate.cer .
scp -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15:~/certs/kafka/kafkasandbox/BCBSNCIntermediate.key .

# Import into Vault (follow 4-on-vault-server.md)
```

#### Step 3: Configure Certificate Automation

```bash
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Create main.tf (see documentation files)
# Create variables.tf
# Create terraform.tfvars

# Initialize
terraform init

# Deploy
terraform apply
```

#### Step 4: Production Configuration

```bash
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Edit terraform.tfvars for production
nano terraform.tfvars
```

**Production settings:**
```hcl
cert_ttl = "8760h"              # 1 year
renewal_threshold = 604800      # 7 days (in seconds)
```

#### Step 5: Setup Cron Job

```bash
# Edit crontab
crontab -e

# Add this line (runs daily at 2 AM):
0 2 * * * cd /home/cafanwii/vault-2026/3-cert-automation/kafka-terraform-cert-automation && /usr/bin/terraform apply -auto-approve >> /var/log/kafka-cert-renewal.log 2>&1
```

### Certificate Locations

#### On Vault Server (vault-pixie):

```bash
# Generated certificates
~/vault-2026/3-cert-automation/vault-generated-certs/
├── mainframe.crt       # Server certificate
├── mainframe.key       # Private key
├── ca-chain.crt        # CA chain
└── issuing-ca.crt      # Issuing CA

# Imported CA certificates
~/vault-2026/3-cert-automation/existing-certs/
├── BCBSNCRoot.cer
├── BCBSNCIntermediate.cer
└── BCBSNCIntermediate.key
```

#### On Kafka Server (mainframe):

```bash
# Deployed certificates
/home/cafanwii/certs/kafka/kafkasandbox/
├── mainframe.crt       # Server certificate (deployed)
├── mainframe.key       # Private key (deployed)
└── ca-chain.crt        # CA chain (deployed)
```

---

## Verification & Testing

### Check Vault Status

```bash
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"

# Vault status
vault status

# List policies
vault policy list

# List users
vault list auth/userpass/users

# List auth methods
vault auth list

# List secret engines
vault secrets list

# List PKI certificates
vault list pki_int/certs
```

### Check Certificate Automation

```bash
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Check Terraform state
terraform show

# Check outputs
terraform output

# View certificate on Kafka server
ssh -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15 \
  'openssl x509 -in ~/certs/kafka/kafkasandbox/mainframe.crt -noout -subject -dates'
```

### Monitor Certificate Renewal

```bash
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Run monitoring script
./watch-renewal.sh

# Check cron job
crontab -l

# Check renewal logs
tail -f /var/log/kafka-cert-renewal.log
```

---

## Maintenance & Operations

### Adding New Users

```bash
cd ~/vault-2026/2-terraformIAM/

# Edit terraform.tfvars
nano terraform.tfvars

# Add new user to appropriate team:
middleware_users = {
  middleware1 = "Pass1!"
  middleware2 = "Pass2!"
  middleware3 = "Pass3!"
  middleware4 = "Pass4!"  # New user
}

# Apply changes
terraform apply
```

### Rotating Passwords

```bash
cd ~/vault-2026/2-terraformIAM/

# Edit terraform.tfvars with new passwords
nano terraform.tfvars

# Apply
terraform apply
```

### Updating Policies

```bash
cd ~/vault-2026/2-terraformIAM/

# Edit policy file
nano policies/middleware-policy.hcl

# Apply changes
terraform apply
```

### Certificate Renewal Timeline

```
Day 1:   Certificate issued (expires Day 365)
Day 358: Renewal threshold reached (7 days remain)
Day 359: Cron job runs at 2 AM
         ├─ Terraform detects threshold
         ├─ Generates new certificate
         ├─ Deploys to mainframe
         └─ Logs to /var/log/kafka-cert-renewal.log
Day 359+: New certificate valid for another year
```

### Backup Procedures

```bash
# Backup Terraform state
cd ~/vault-2026/2-terraformIAM/
cp terraform.tfstate terraform.tfstate.backup.$(date +%Y%m%d)

cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/
cp terraform.tfstate terraform.tfstate.backup.$(date +%Y%m%d)

# Backup certificates
cd ~/vault-2026/3-cert-automation/
tar -czf vault-certs-backup-$(date +%Y%m%d).tar.gz existing-certs/ vault-generated-certs/
```

---

## Quick Reference Commands

### Environment Setup

```bash
# Always set these before Vault commands
export VAULT_ADDR="https://vault.pixiescloud.com"
export VAULT_TOKEN="hvs.iW6EPgGHfN8aFGGKjEDuDxmG"
vault login $VAULT_TOKEN
```

### Common Paths

```bash
# IAM/Permissions
cd ~/vault-2026/2-terraformIAM/

# Certificate Automation
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Generated Certificates
cd ~/vault-2026/3-cert-automation/vault-generated-certs/

# Imported CA
cd ~/vault-2026/3-cert-automation/existing-certs/
```

### Testing Logins

```bash
# Middleware
vault login -method=userpass username=middleware1

# Security  
vault login -method=userpass username=security1

# HCL
vault login -method=userpass username=hcl1

# Admin
vault login -method=userpass username=admin1

# LDAP
vault login -method=ldap username=<your_ad_username>
```

---

## Troubleshooting

### Issue: Terraform state locked

```bash
cd ~/vault-2026/2-terraformIAM/
# or
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/

# Force unlock (use lock ID from error message)
terraform force-unlock <lock_id>
```

### Issue: Permission denied

```bash
# Check which user you're logged in as
vault token lookup

# Re-login as correct user
vault login -method=userpass username=<username>
```

### Issue: Certificate not deploying

```bash
# Check SSH key
ssh -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15

# Check Terraform logs
cd ~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/
terraform apply

# Check deployment log on Kafka server
ssh -i ~/.ssh/kafka-deploy cafanwii@10.0.0.15 \
  'cat ~/certs/kafka/kafkasandbox/vault-deployment.log'
```

---

## Directory Navigation Cheat Sheet

| Task | Directory |
|------|-----------|
| Install/Reset Vault | `~/vault-2026/1-installing-vault-ansible/` |
| Manage Users/Policies | `~/vault-2026/2-terraformIAM/` |
| Edit Policies | `~/vault-2026/2-terraformIAM/policies/` |
| Certificate Automation | `~/vault-2026/3-cert-automation/kafka-terraform-cert-automation/` |
| View Generated Certs | `~/vault-2026/3-cert-automation/vault-generated-certs/` |
| View Imported CA | `~/vault-2026/3-cert-automation/existing-certs/` |
| Setup Documentation | `~/vault-2026/3-cert-automation/*.md` |

---

## Support

For issues or questions:
1. Check the documentation files in each directory
2. Review Terraform outputs: `terraform output`
3. Check Vault logs: `journalctl -u vault -f`
4. Verify Vault status: `vault status`

---

**Document maintained by Vault Administration Team**  
**Last verified:** January 18, 2026
